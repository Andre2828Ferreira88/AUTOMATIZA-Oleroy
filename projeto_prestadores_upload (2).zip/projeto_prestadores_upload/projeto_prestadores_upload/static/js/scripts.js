document.addEventListener('DOMContentLoaded', function() {
    const buscarDesktop = document.getElementById('buscarDesktop');
    const listaDesktop = document.getElementById('listaPrestadoresDesktop');
    const buscarMobile = document.getElementById('buscarMobile');
    const listaMobile = document.getElementById('listaPrestadoresMobile');

    function filterList(inputEl, listEl) {
        if (!inputEl || !listEl) return;
        inputEl.addEventListener('input', function() {
            const q = inputEl.value.toLowerCase().trim();
            const items = listEl.querySelectorAll('a');
            items.forEach(a => {
                const text = a.textContent.toLowerCase();
                if (text.includes(q)) a.style.display = '';
                else a.style.display = 'none';
            });
        });
    }

    filterList(buscarDesktop, listaDesktop);
    filterList(buscarMobile, listaMobile);
});
