import os
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
import pandas as pd
import json
from collections import defaultdict, Counter
import datetime

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'dados')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ALLOWED_EXTENSIONS = {'csv', 'xls', 'xlsx'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = 'dev-secret'  # trocar em produção

# In-memory storage for processed data (reset on restart)
STATE = {
    'last_upload': None,
    'prestadores': {}  # id -> dict
}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def process_file(path):
    # try reading with pandas with latin1 fallback
    try:
        df = pd.read_csv(path, encoding='utf-8', engine='python', sep=None)
    except Exception:
        df = pd.read_csv(path, encoding='latin1', engine='python', sep=None)

    # Normalize column names to expected ones (strip spaces)
    df.columns = [c.strip() for c in df.columns]

    # We expect at least 'Nome' and 'Grupo de serviços' columns
    if 'Nome' not in df.columns or 'Grupo de serviços' not in df.columns:
        raise ValueError('Arquivo não contém colunas esperadas "Nome" e "Grupo de serviços".')

    # Each row is a service performed by the prestador in that month
    # We'll group by Nome and count types
    prestadores = {}
    for nome, group in df.groupby('Nome'):
        tipos_counter = Counter(group['Grupo de serviços'].fillna('Desconhecido').astype(str).tolist())
        prestadores[nome] = {
            'id': secure_filename(nome).lower().replace(' ', '_'),
            'nome': nome,
            'total': int(sum(tipos_counter.values())),
            'tipos': dict(tipos_counter)
        }
    return prestadores

@app.route('/', methods=['GET', 'POST'])
def dashboard():
    if request.method == 'POST':
        # handle file upload
        if 'file' not in request.files:
            flash('Nenhum arquivo selecionado', 'danger')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('Nenhum arquivo selecionado', 'danger')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            ts = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            save_name = f"{ts}_{filename}"
            path = os.path.join(app.config['UPLOAD_FOLDER'], save_name)
            file.save(path)
            try:
                prestadores = process_file(path)
            except Exception as e:
                flash(f'Erro ao processar arquivo: {e}', 'danger')
                return redirect(request.url)
            # update state
            STATE['last_upload'] = {'filename': save_name, 'original': filename, 'time': ts}
            STATE['prestadores'] = prestadores
            flash(f'Arquivo {filename} carregado e processado com sucesso!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Formato de arquivo não permitido. Use CSV/XLS/XLSX.', 'danger')
            return redirect(request.url)

    # GET
    prestadores_list = [{'id': v['id'], 'nome': v['nome']} for v in STATE['prestadores'].values()]
    last = STATE['last_upload']
    return render_template('dashboard.html', prestadores=prestadores_list, last=last)

@app.route('/prestador/<path:prestador_id>')
def prestador(prestador_id):
    # find prestador by id
    p = None
    for v in STATE['prestadores'].values():
        if v['id'] == prestador_id:
            p = v
            break
    if not p:
        return 'Prestador não encontrado. Faça upload de uma planilha primeiro.', 404

    tipos = list(p['tipos'].keys())
    tipos_val = list(p['tipos'].values())

    # For a simple monthly bar chart we'll show counts by tipo (since only one month uploaded)
    meses = tipos  # reuse for display; frontend chart labels are generic
    valores = tipos_val

    return render_template('prestador.html',
                           prestador=p,
                           meses=json.dumps(meses, ensure_ascii=False),
                           valores=json.dumps(valores),
                           tipos=json.dumps(tipos, ensure_ascii=False),
                           tipos_val=json.dumps(tipos_val))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
